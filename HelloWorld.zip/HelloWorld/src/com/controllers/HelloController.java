package com.controllers;
import org.springframework.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.portlet.ModelAndView;

import jdk.internal.org.objectweb.asm.commons.Method;

import org.springframework.ui.ModelMap;



@Controller
@RequestMapping(value="/")
public class HelloController 
{
@RequestMapping(method=RequestMethod.GET)
	public ModelAndView printHello()
	{
		return new ModelAndView("Hello","message","My name is Mayank and I have created this Spring MVC ");
		
	}
}


